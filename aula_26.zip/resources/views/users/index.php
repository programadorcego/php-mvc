<h1>Usuários</h1>

<a href="<?php echo asset('user/create'); ?>">Criar Novo</a>

<?php $this->render('layout/messages'); ?>

<table>
	<thead>
		<tr>
			<th>ID</th>
			<th>Nome</th>
			<th>E-mail</th>
			<th></th>
		</tr>
	</thead>
	
	<tbody>
	<?php if($users): ?>
		<?php foreach($users as $user) : ?>
			<tr>
				<td><?php echo $user->id; ?></td>
				<td><a href="<?php echo asset("user/edit/{$user->id}"); ?>"><?php echo $user->username; ?></a></td>
				<td><?php echo $user->email; ?></td>
				<td>
					<form action="<?php echo asset("user/delete/{$user->id}"); ?>" method="POST">
						<input type="hidden" name="_method" value="DELETE">
						<button>Excluir</button>
					</form>
				</td>
			</tr>
		<?php endforeach; ?>
	<?php else : ?>
		<tr>
			<td colspan="4">Nenhum usuário cadastrado</td>
		</tr>
	<?php endif; ?>
	</tbody>
</table>

<?php echo $pagination->getNavigation(); ?>