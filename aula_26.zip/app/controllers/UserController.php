<?php
namespace App\Controllers;

use App\Controllers\PageController;
use App\Models\User;
use App\Utils\Redirect;
use App\Utils\Session;
use App\Http\Response;
use App\Http\Request;
use Exception;
use App\Core\Pagination;

class UserController extends PageController
{
	/*protected $user;
	
	public function __construct()
	{
		$this->user = new User();
	}*/
	
	public function index(Request $request, User $user)
	{
		$title = "Usuários";
		$queryParams = $request->getQueryParams();
		$currentPage = $queryParams['page'] ?? 1;
		
		try
		{
			$pagination = new Pagination($this->getTotalUsers(), $currentPage, 5);
			$users = $this->getUsers($pagination);
			$this->renderLayout("users/index", compact('title', 'users', 'pagination'));
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
	
	private function getTotalUsers()
	{
		try
		{
			// SELECT COUNT(*) AS total FROM usuarios
			return (new User())->read('COUNT(*) AS total')->fetchObject()->total;
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
	
	private function getUsers(Pagination $pagination)
	{
		// SELECT * FROM usuarios Limit 0, 10
		return (new User())->read(limit: $pagination->getLimit())->fetchAll(\PDO::FETCH_CLASS, User::class);
	}
	
	public function create()
	{
		$title = "Novo Usuário";
		$this->renderLayout("users/create", compact('title'));
	}
	
	public function store(User $user, Request $request)
	{
		$data = $request->getPostParams();
		$data['password'] = md5($data['password']);
		unset($data['password_confirm']);
		
		try
		{
			$user = $user->create($data);
			
			Redirect::to('user/edit/' . $user->id, ['success' => 'Usuário cadastrado com sucesso!']);
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
	
	public function edit($id)
	{
		$title = 'Editar Usuário';
		
		try
		{
			$user = (new User())->find($id);
			$this->render('users/edit', compact('title', 'user'));
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
	
	public function update(Request $request, $id)
	{
		$data = $request->getPostParams();
		
		if($data['password'] === "")
		{
			unset($data['password']);
		} else
		{
			$data['password'] = md5($data['password']);
		}
		
		unset($data['password_confirm']);
		
		try
		{
			$user = (new User())->update($data, $id);
			Redirect::to("user/edit/{$id}", ['success' => 'Usuário salvo com sucesso!']);
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
	
	public function delete($id)
	{
		try
		{
			$user = (new User())->delete($id);
			Redirect::to('users', ['success' => 'Usuário removido com sucesso!']);
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
}