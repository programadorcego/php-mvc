<?php
$route->get("/", "\\App\\Controllers\\HomeController@index");
$route->get("users", "\\App\\Controllers\\UserController@index");
$route->get("user/create", "\\App\\Controllers\\UserController@create");
$route->post("user/create", "\\App\\Controllers\\UserController@store");
$route->get("user/edit/{id}", "\\App\\Controllers\\UserController@edit");
$route->put("user/edit/{id}", "\\App\\Controllers\\UserController@update");
$route->delete("user/delete/{id}", "\\App\\Controllers\\UserController@delete");