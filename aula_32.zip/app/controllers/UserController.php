<?php
namespace App\Controllers;

use App\Controllers\PageController;
use App\Models\User;
use App\Utils\Redirect;
use App\Utils\Session;
use App\Http\Response;
use App\Http\Request;
use Exception;
use App\Core\Pagination;
use App\Http\Validate;

class UserController extends PageController
{
	/*protected $user;
	
	public function __construct()
	{
		$this->user = new User();
	}*/
	
	public function index(Request $request, User $user)
	{
		$title = "Usuários";
		$queryParams = $request->getQueryParams();
		$currentPage = $queryParams['page'] ?? 1;
		
		try
		{
			$pagination = new Pagination($this->getTotalUsers($queryParams), $currentPage, 5);
			$users = $this->getUsers($queryParams, $pagination);
			$this->renderLayout("users/index", compact('title', 'users', 'pagination'));
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
	
	private function getTotalUsers($queryParams)
	{
		$search = $queryParams['search'] ?? "";
		$search = str_replace(' ', '%', $search);
		
		try
		{
			// SELECT COUNT(*) AS total FROM usuarios WHERE username LIKE '%valor%' OR email LIKE '%valor%'
			return (new User())->read(fields: 'COUNT(*) AS total', where: "username LIKE '%{$search}%' OR email LIKE '%{$search}%'")->fetchObject()->total;
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
	
	private function getUsers($queryParams, Pagination $pagination)
	{
		// SELECT * FROM usuarios WHERE username LIKE '%valor%' OR email LIKE '%valor%' Limit 0, 10
		$search = $queryParams['search'] ?? "";
		$search = str_replace(' ', '%', $search);
		return (new User())->read(where: "username LIKE '%{$search}%' OR email LIKE '%{$search}%'", limit: $pagination->getLimit())->fetchAll(\PDO::FETCH_CLASS, User::class);
	}
	
	public function create()
	{
		$title = "Novo Usuário";
		$this->renderLayout("users/create", compact('title'));
	}
	
	public function store(User $user, Request $request)
	{
		$data = $request->getPostParams();
		
		$rules = [
			'username' => 'required',
			'email' => 'required|email|unique:'.User::class,
			'password' => 'required|min:8|max:16|confirm',
		];
		
		$messages = [
			'username.required' => 'O nome de usuário é obrigatório!',
		];
		
		$validate = Validate::make($data, $rules, $messages);
		
		if(!$validate->validate())
		{
			Redirect::to('user/create', ['errors' => $validate->getErrors(), ...$data]);
		}
		
		$data['password'] = md5($data['password']);
		unset($data['password_confirm']);
		
		try
		{
			$user = $user->create($data);
			
			Redirect::to('user/edit/' . $user->id, ['success' => 'Usuário cadastrado com sucesso!']);
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
	
	public function edit($id)
	{
		$title = 'Editar Usuário';
		
		try
		{
			$user = (new User())->find($id);
			$this->render('users/edit', compact('title', 'user'));
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
	
	public function update(Request $request, $id)
	{
		$data = $request->getPostParams();
		
		$rules = [
			'username' => 'required',
			'email' => 'required|email|unique:'.User::class.',,'.$id,
		];
		
		if(!empty(trim($data['email'])))
		{
			$rules['password'] = 'min:8|max:16|confirm';
		}
		
		$messages = [
			'username.required' => 'O nome de usuário é obrigatório!',
		];
		
		$validate = Validate::make($data, $rules, $messages);
		
		if(!$validate->validate())
		{
			Redirect::to("user/edit/{$id}", ['errors' => $validate->getErrors(), ...$data]);
		}
		
		if($data['password'] === "")
		{
			unset($data['password']);
		} else
		{
			$data['password'] = md5($data['password']);
		}
		
		unset($data['password_confirm']);
		
		try
		{
			$user = (new User())->update($data, $id);
			Redirect::to("user/edit/{$id}", ['success' => 'Usuário salvo com sucesso!']);
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
	
	public function delete($id)
	{
		try
		{
			$user = (new User())->delete($id);
			Redirect::to('users', ['success' => 'Usuário removido com sucesso!']);
		} catch(Exception $e)
			{
				return (new Response(200, $e->getMessage()))->sendResponse();
			}
	}
}