<?php
$route->get("admin", "\\App\\Controllers\\HomeController@index", ['require-admin-login']);
$route->get("admin/users", "\\App\\Controllers\\UserController@index", ['require-admin-login']);
$route->get("admin/user/create", "\\App\\Controllers\\UserController@create", ['require-admin-login']);
$route->post("admin/user/create", "\\App\\Controllers\\UserController@store", ['require-admin-login']);
$route->get("admin/user/edit/{id}", "\\App\\Controllers\\UserController@edit", ['require-admin-login']);
$route->put("admin/user/edit/{id}", "\\App\\Controllers\\UserController@update", ['require-admin-login']);
$route->delete("admin/user/delete/{id}", "\\App\\Controllers\\UserController@delete", ['require-admin-login']);

$route->get('login', '\\App\\Controllers\\AuthController@index', ['require-admin-logout']);
$route->post('login', '\\App\\Controllers\\AuthController@login', ['require-admin-logout']);
$route->get('admin/logout', '\\App\\Controllers\\AuthController@logout', ['require-admin-login']);