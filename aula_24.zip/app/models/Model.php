<?php
namespace App\Models;

use App\Core\Database;
use App\Http\Response;
use Exception;

class Model
{
	protected $table;
	private $db;
	
	public function __construct()
	{
		$this->db = new Database();
	}
	
	public function all()
	{
		try
		{
			$results = $this->db->read($this->table);
			return $results;
		} catch(Exception $e)
			{
				throw new Exception($e->getMessage());
			}
	}
	
	public function create(array $data)
	{
		try
		{
			$id = $this->db->create($this->table, $data);
			return $this->find($id);
		} catch(Exception $e)
			{
				throw new Exception($e->getMessage());
			}
	}
	
	public function find($id)
	{
		try
		{
			return $this->db->read($this->table, $id);
		} catch(Exception $e)
			{
				throw new Exception($e->getMessage());
			}
	}
	
	public function update($data, $id)
	{
		try
		{
			$this->db->update($this->table, $data, $id);
			return $this->find($id);
		} catch(Exception $e)
			{
				throw new Exception($e->getMessage());
			}
	}
}