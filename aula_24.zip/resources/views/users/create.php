<h1>Novo Usuário</h1>

<?php $this->render('layout/messages'); ?>

<form action="<?php echo asset('user/create'); ?>" method="POST">
	<?php $this->render('users/form'); ?>
</form>