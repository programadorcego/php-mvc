<?php
namespace App\Http;

use App\Http\Request;
use App\Http\Response;
use Exception;

class Route
{
	private $routes = [];
	private $request;
	
	public function __construct()
	{
		$this->request = new Request();
	}
	
	private function addRoute($httpMethod, $route, $controller)
	{
		list($controller, $action) = explode('@', $controller);
		$routes = [];
		
		$routes['controller'] = $controller;
		$routes['action'] = $action;
		
		$routePattern = '/^' . str_replace('/', '\/', $route) . '$/';
		$this->routes[$routePattern][$httpMethod] = $routes;
	}
	
	public function get($route, $controller)
	{
		$this->addRoute('GET', $route, $controller);
	}
	
	private function getUrl()
	{
		$uri = $this->request->getUri();
		$dirname = pathinfo($_SERVER['PHP_SELF'], PATHINFO_DIRNAME);
		$url = substr($uri, strlen($dirname));
		$url = ltrim($url, '/');
		$url = $url === "" ? '/' : $url;
		return $url;
		//echo $url; exit;
	}
}