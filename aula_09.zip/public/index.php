<?php
require "../vendor/autoload.php";

use App\Http\Route;

$route = new Route();
$route->get("/", "\\App\\Controllers\\HomeController@index");

echo "<pre>";
var_dump($route);
echo "</pre>";