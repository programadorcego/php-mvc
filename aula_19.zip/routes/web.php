<?php
$route->get("/", "\\App\\Controllers\\HomeController@index");