<h1>Usuários</h1>

<table>
	<thead>
		<tr>
			<th>ID</th>
			<th>Nome</th>
		</tr>
	</thead>
</table>