<?php
namespace App\Controllers;

use App\Controllers\PageController;
use App\Utils\Session;

class HomeController extends PageController
{
	public function index()
	{
		$title = "Home";
		//$this->renderLayout("home/index", compact('title'));
		//Session::flush('nome', 'Willian');
		echo Session::get('nome');
	}
}