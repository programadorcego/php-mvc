<?php
namespace App\Controllers;

use App\Controllers\PageController;
use App\Models\User;
use App\Utils\Redirect;
use App\Utils\Session;
use App\Http\Response;
use App\Http\Request;
use Exception;

class UserController extends PageController
{
	/*protected $user;
	
	public function __construct()
	{
		$this->user = new User();
	}*/
	
	public function index(User $user)
	{
		$title = "Usuários";
		$users = $user->all();
		$this->renderLayout("users/index", compact('title', 'users'));
	}
	
	public function create()
	{
		$title = "Novo Usuário";
		$this->renderLayout("users/create", compact('title'));
	}
	
	public function store(User $user, Request $request)
	{
		$data = $request->getPostParams();
		$data['password'] = md5($data['password']);
		unset($data['password_confirm']);
		
		try
		{
			$user = $user->create($data);
			
			Redirect::to('user/edit/' . $user->id, ['message' => 'Usuário cadastrado com sucesso!']);
		} catch(Exception $e)
			{
				return (new Response($e->getCode(), $e->getMessage()))->sendResponse();
			}
	}
}