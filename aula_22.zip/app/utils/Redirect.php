<?php
namespace App\Utils;

use App\Utils\Session;

class Redirect
{
	public static function to($path, array $with = [])
	{
		if(count($with))
		{
			Session::flush('with', $with);
		}
		
		header("Location: " . asset($path));
	}
}