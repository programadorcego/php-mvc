<h1>Usuários</h1>

<a href="<?php echo asset('user/create'); ?>">Criar Novo</a>

<table>
	<thead>
		<tr>
			<th>ID</th>
			<th>Nome</th>
		</tr>
	</thead>
	
	<tbody>
	<?php if($users): ?>
		<?php foreach($users as $user) : ?>
			<tr>
				<td><?php echo $user->id; ?></td>
				<td><?php echo $user->name; ?></td>
			</tr>
		<?php endforeach; ?>
	<?php else : ?>
		<tr>
			<td colspan="2">Nenhum usuário cadastrado</td>
		</tr>
	<?php endif; ?>
	</tbody>
</table>