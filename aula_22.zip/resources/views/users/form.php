	<div>
		<p><label for="name">Nome de Usuário *</label></p>
		<p><input type="text" name="name" id="name" placeholder="Informe o nome de usuário" required></p>
	</div>
	
	<div>
		<p><label for="password">Senha *</label></p>
		<p><input type="password" name="password" id="password" placeholder="Informe a senha" minlength="8" maxlength="16" required></p>
	</div>
	
	<div>
		<p><label for="password_confirm">Confirme a Senha *</label></p>
		<p><input type="password" name="password_confirm" id="password_confirm" placeholder="Confirme a senha" minlength="8" maxlength="16" required></p>
	</div>
	
	<div>
		<button>Salvar</button>
	</div>