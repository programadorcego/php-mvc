<?php
namespace App\Controllers;

use App\Controllers\Controller;

class PageController extends Controller
{
	protected function renderLayout($view, $data = [])
	{
		$this->render("layout/header", $data);
		$this->render($view, $data);
		$this->render("layout/footer", $data);
	}
}