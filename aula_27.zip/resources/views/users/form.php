	<div>
		<p><label for="username">Nome de Usuário *</label></p>
		<p><input type="text" name="username" id="username" placeholder="Informe o nome de usuário" required value="<?php if(isset($user)) echo $user->username; ?>"></p>
	</div>
	
	<div>
		<p><label for="email">E-mail *</label></p>
		<p><input type="email" name="email" id="username" placeholder="Informe um e-mail válido" required value="<?php if(isset($user)) echo $user->email; ?>"></p>
	</div>
	
	<div>
		<p><label for="password">Senha *</label></p>
		<p><input type="password" name="password" id="password" placeholder="Informe a senha" <?php if(!isset($user)) echo 'required'; ?>></p>
	</div>
	
	<div>
		<p><label for="password_confirm">Confirme a Senha *</label></p>
		<p><input type="password" name="password_confirm" id="password_confirm" placeholder="Confirme a senha" <?php if(!isset($user)) echo 'required'; ?>></p>
	</div>
	
	<div>
		<button>Salvar</button>
	</div>