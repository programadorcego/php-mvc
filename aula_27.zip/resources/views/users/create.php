<h1>Novo Usuário</h1>

<a href="<?php echo asset('users'); ?>">Cancelar</a>

<?php $this->render('layout/messages'); ?>

<form action="<?php echo asset('user/create'); ?>" method="POST">
	<?php $this->render('users/form'); ?>
</form>