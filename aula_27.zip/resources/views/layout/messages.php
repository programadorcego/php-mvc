<?php if(\App\Utils\Session::has('success')) : ?>
	<div class="alert-success">
		<?php echo \App\Utils\Session::get('success'); ?>
	</div>
<?php endif; ?>