<?php
$route->get("/", "\\App\\Controllers\\HomeController@index");
$route->get("users", "\\App\\Controllers\\UserController@index");
$route->get("user/create", "\\App\\Controllers\\UserController@create");