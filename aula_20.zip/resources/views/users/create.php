<h1>Novo Usuário</h1>

<form action="<?php echo $_ENV['SITE_URL']; ?>/user/create" method="POST">
	<?php $this->render('users/form'); ?>
</form>