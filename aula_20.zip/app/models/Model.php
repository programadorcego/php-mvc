<?php
namespace App\Models;

use App\Core\Database;
use Exception;

class Model
{
	protected $table;
	private $db;
	
	public function __construct()
	{
		$this->db = new Database();
	}
	
	public function all()
	{
		try
		{
			$results = $this->db->read($this->table);
			return $results;
		} catch(Exception $e)
			{
				throw new Exception($e->getMessage());
			}
	}
}