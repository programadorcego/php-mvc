<?php
namespace App\Controllers;

use App\Controllers\PageController;
use App\Utils\Session;
use App\Models\User;

class UserController extends PageController
{
	public function index()
	{
		$title = "Usuários";
		$user = new User();
		$users = $user->all();
		$this->renderLayout("users/index", compact('title', 'users'));
	}
	
	public function create()
	{
		$title = "Novo Usuário";
		$this->renderLayout("users/create", compact('title'));
	}
}