<?php
require "../vendor/autoload.php";

use App\Http\Request;

$request = new Request();
//echo $request->getHttpMethod();

//print_r($request->getQueryParams());

//print_r($request->getHeaders());

echo $request->getUri();