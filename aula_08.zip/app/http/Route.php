<?php
namespace App\Http;

use App\Http\Request;
use App\Http\Response;
use Exception;

class Route
{
	private $routes = [];
	private $request;
	
	public function __construct()
	{
		$this->request = new Request();
	}
	
	public function get($route, $controller)
	{
		print $route . "<br>" . $controller;
		exit;
	}
}