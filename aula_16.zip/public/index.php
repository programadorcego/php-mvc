<?php
require "../vendor/autoload.php";

use App\Http\Route;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

$route = new Route();
$route->get("/", "\\App\\Controllers\\HomeController@index");
$route->get("produto/{id}", "\\App\\Controllers\\ProductController@index");
$route->run();