<p>Esta é a minha Home</p>
<pre>
	<?php print_r($_ENV); ?>
</pre>