<?php
namespace App\Controllers;

use App\Controllers\PageController;

class UserController extends PageController
{
	public function create()
	{
		$title = "Usuário - Criar Novo";
		$this->renderLayout("users/create", compact('title'));
	}
}