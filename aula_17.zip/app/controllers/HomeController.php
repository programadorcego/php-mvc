<?php
namespace App\Controllers;

use App\Controllers\PageController;

class HomeController extends PageController
{
	public function index()
	{
		$title = "Home";
		//$this->renderLayout("home/index", compact('title'));
		dd($_SERVER);
	}
}