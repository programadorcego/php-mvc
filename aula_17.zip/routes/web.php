<?php
$route->get("/", "\\App\\Controllers\\HomeController@index");


$route->get("user/create", "\\App\\Controllers\\UserController@create");