<?php
namespace App\Core;

class Container
{
	public static function instance($route)
	{
		$controller = new $route['controller']();
		return $controller->{$route['action']}();
	}
}