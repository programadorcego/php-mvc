<?php
namespace App\Core;

use PDO;
use PDOException;
use Exception;

class Database
{
	private $pdo;
	
	public function __construct()
	{
		$dsn = "mysql:host=" . $_ENV['DB_HOST'] . ";dbname=" . $_ENV['DB_NAME'];
		
		try
		{
			$this->pdo = new PDO($dsn, $_ENV['DB_USER'], $_ENV['DB_PASSWORD'], [PDO::ATTR_PERSISTENT => true]);
			$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
		} catch(PDOException $e)
			{
				throw new Exception("Erro na conexxão! " . $e->getMessage(), $e->getCode());
			}
	}
	
	public function read(string $table, int $id = 0)
	{
		try
		{
			$sql = "SELECT * FROM $table WHERE 1";
			
			if($id > 0)
			{
				$sql .= " AND id = $id LIMIT 1";
			}
			
			$stmt = $this->pdo->prepare($sql);
			$stmt->execute();
			
			if($id > 0)
			{
				$results = $stmt->fetch();
				return $results;
			}
			
			$results = $stmt->fetchAll();
			return $results;
		} catch(PDOException $e){
			throw new Exception($e->getMessage(), $e->getCode());
		}
	}
	
	public function create(string $table, array $data)
	{
		$columns = implode(", ", array_keys($data));
		$values = implode(", ", array_fill(0, count($data), "?"));
		
		try 
		{
			$sql = "INSERT INTO $table ($columns) VALUES ($values)";
			$stmt = $this->pdo->prepare($sql);
			$stmt->execute(array_values($data));
			
			$id = $this->pdo->lastInsertId();
		return $id;
		} catch(PDOException $e)
		{
			throw new Exception("Erro! " . $e->getMessage(), $e->getCode());
		}
	}
}