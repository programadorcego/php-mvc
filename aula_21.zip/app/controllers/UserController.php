<?php
namespace App\Controllers;

use App\Controllers\PageController;
use App\Models\User;
use App\Utils\Redirect;
use App\Utils\Session;
use App\Http\Response;
use App\Http\Request;
use Exception;

class UserController extends PageController
{
	public function index()
	{
		$title = "Usuários";
		$user = new User();
		$users = $user->all();
		$this->renderLayout("users/index", compact('title', 'users'));
	}
	
	public function create()
	{
		$title = "Novo Usuário";
		$this->renderLayout("users/create", compact('title'));
	}
	
	public function store()
	{
		$request = new Request();
		$data = $request->getPostParams();
		$data['password'] = md5($data['password']);
		unset($data['password_confirm']);
		
		try
		{
			$user = (new User())->create($data);
			
			Redirect::to('user/edit/' . $user->id, ['message' => 'Usuário cadastrado com sucesso!']);
		} catch(Exception $e)
			{
				return (new Response($e->getCode(), $e->getMessage()))->sendResponse();
			}
	}
}