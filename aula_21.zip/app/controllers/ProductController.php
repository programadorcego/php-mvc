<?php
namespace App\Controllers;

use App\Controllers\PageController;

class ProductController extends PageController
{
	public function index($id)
	{
		echo $id;
	}
}