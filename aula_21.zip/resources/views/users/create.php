<h1>Novo Usuário</h1>

<form action="<?php echo asset('user/create'); ?>" method="POST">
	<?php $this->render('users/form'); ?>
</form>