<h1>Editar Usuário</h1>

<?php $this->render('layout/messages'); ?>

<form action="<?php echo asset("user/edit/{$user->id}"); ?>" method="POST">
	<input type="hidden" name="_method" value="PUT">
	
	<?php $this->render('users/form', compact('user')); ?>
</form>