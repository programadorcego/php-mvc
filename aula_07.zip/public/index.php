<?php
require "../vendor/autoload.php";

use App\Http\Response;

$response = new Response(200, "Meu conteúdo");
$response->sendResponse();