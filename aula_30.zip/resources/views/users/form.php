	<div>
		<p><label for="username">Nome de Usuário *</label></p>
		<p><input type="text" name="username" id="username" placeholder="Informe o nome de usuário" value="<?php if(\App\Utils\Session::has('username')) echo \App\Utils\Session::get('username'); else if(isset($user)) echo $user->username; ?>"></p>
	</div>
	
	<div>
		<p><label for="email">E-mail *</label></p>
		<p><input type="text" name="email" id="username" placeholder="Informe um e-mail válido" value="<?php if(\App\Utils\Session::has('email')) echo \App\Utils\Session::get('email'); else if(isset($user)) echo $user->email; ?>"></p>
	</div>
	
	<div>
		<p><label for="password">Senha *</label></p>
		<p><input type="password" name="password" id="password" placeholder="Informe a senha"></p>
	</div>
	
	<div>
		<p><label for="password_confirm">Confirme a Senha *</label></p>
		<p><input type="password" name="password_confirm" id="password_confirm" placeholder="Confirme a senha"></p>
	</div>
	
	<div>
		<button>Salvar</button>
	</div>