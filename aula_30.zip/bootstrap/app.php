<?php
use App\Http\Middlewares\MiddlewareQueue;
use App\Http\Middlewares\Maintenance;

MiddlewareQueue::setMap([
	'maintenance' => Maintenance::class,
]);

MiddlewareQueue::setDefaultMiddlewares(['maintenance']);