<?php
$route->get("admin", "\\App\\Controllers\\HomeController@index");
$route->get("admin/users", "\\App\\Controllers\\UserController@index", ['maintenance']);
$route->get("admin/user/create", "\\App\\Controllers\\UserController@create");
$route->post("admin/user/create", "\\App\\Controllers\\UserController@store");
$route->get("admin/user/edit/{id}", "\\App\\Controllers\\UserController@edit");
$route->put("admin/user/edit/{id}", "\\App\\Controllers\\UserController@update");
$route->delete("admin/user/delete/{id}", "\\App\\Controllers\\UserController@delete");

$route->get('login', '\\App\\Controllers\\AuthController@index');
$route->post('login', '\\App\\Controllers\\AuthController@login');