<?php
namespace App\Controllers;

use App\Controllers\PageController;
use App\Utils\Session;

class HomeController extends PageController
{
	public function index()
	{
		$title = "Painel Administrativo";
		$this->renderLayout('dashboard/index', compact('title'));
	}
}