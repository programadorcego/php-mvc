<h1>Editar Usuário</h1>

<a href="<?php echo asset('users'); ?>">Cancelar</a>

<?php $this->render('layout/messages'); ?>

<form action="<?php echo asset("user/edit/{$user->id}"); ?>" method="POST">
	<input type="hidden" name="_method" value="PUT">
	
	<?php $this->render('users/form', compact('user')); ?>
</form>