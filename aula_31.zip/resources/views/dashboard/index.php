<h1>Painel Administrativo</h1>

<a href="<?php echo asset('admin/users'); ?>">Usuários</a>

<p>Bem-vindo</p>