<h1>Login</h1>

<?php $this->render('layout/messages'); ?>

<div>
	<form action="<?php echo asset('login'); ?>" method="POST">
			<div>
			<label for="username">Nome de usuário *</label>
			<input type="text" id="username" name="username" placeholder="Entre com o nome de usuário ou e-mail" required>
		</div>
		
		<div>
			<label for="password">Senha</label>
			<input type="password" id="password" name="password" placeholder="Informe a senha" required>
		</div>
		
		<div>
		<button>Entrar</button>
	</div>
	</form>
</div>